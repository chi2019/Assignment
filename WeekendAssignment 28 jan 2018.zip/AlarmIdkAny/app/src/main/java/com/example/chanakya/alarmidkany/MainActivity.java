package com.example.chanakya.alarmidkany;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    /**
     * This class is used conduct
     *  quiz for a  particular user
     */

    Button trueButton;
    Button falseButton;
    Button nextButton;
    TextView displayText;
    boolean[] userEvaluation = new boolean[10];
    String userName = "";


    private  QuestionBank[] questionBank = new QuestionBank[]{
            new QuestionBank(R.string.qst_txt1,true),
            new QuestionBank(R.string.qst_txt2,true),
            new QuestionBank(R.string.qst_txt3,true),
            new QuestionBank(R.string.qst_txt4,false),
            new QuestionBank(R.string.qst_txt5,false),
            new QuestionBank(R.string.qst_txt6,true),
            new QuestionBank(R.string.qst_txt7,true),
            new QuestionBank(R.string.qst_txt8,true),
            new QuestionBank(R.string.qst_txt9,false),
            new QuestionBank(R.string.qst_txt10,false)

            /**
             * Here  we are creating objects for every question
             * to be asked in the quiz
            */
    };

    int currentIndex= 0;


      public void updateQuestion(int currentIndex){
          int question = questionBank[currentIndex].getQuestion();
          displayText.setText(question);

          /**
           * This method is used to set question to be displayed on the screen.
           * It takes @param currentIndex which is the id of every string in string.xml
           */
      }

    public void checkAnswer(boolean userAnswer){
            boolean isTrue =  questionBank[currentIndex].isQuestiontrue();

        /**
         * This method iss used to check the
         * answer provided by user is corect or wrong.
         * It takes a @param userAnswer which is the answer provided by the user.
         *
         *
         */


        if(userAnswer == isTrue){
             userEvaluation[currentIndex] = true;
            }

            else  userEvaluation[currentIndex] = false;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        trueButton  = (Button) findViewById(R.id.trueButton);
        falseButton = (Button) findViewById(R.id.falseButton);
        nextButton  = (Button) findViewById(R.id.nextButton);
        displayText = (TextView) findViewById(R.id.displayTextView);

        userName = getIntent().getExtras().getString("username").toString();

           trueButton.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                    checkAnswer(true);
               }
           });
        /**
         * Here we are setting onClickListners for both true and false button.
         * If the user presses any of the buttons the following onClickListners are activated
         * and the the checking is done if the user provided correct answer or not.
         */
        falseButton.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                    checkAnswer(false);
               }
           });

        int question = questionBank[currentIndex].getQuestion();
        displayText.setText(question);
        currentIndex++;

        /**
         * This is the onClick listener next button.
         * When the userpresses this button the next question is loaded.
         * If all the questions are attempted by the user, then this
         * onClickListener activates an intent which showsthe ressult to the user.
         */
           nextButton.setOnClickListener(new View.OnClickListener() {
               @Override
                public void onClick(View view) {
                              if(currentIndex != 0) {
                                  currentIndex = (currentIndex +1 ) % questionBank.length;
                                  updateQuestion(currentIndex);
                              }
                         else {
                                  Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                                  intent.putExtra("UserAnswers",userEvaluation);

                                  intent.putExtra("username",userName);
                                  startActivity(intent);
                              }
               }
           });




    }
}
