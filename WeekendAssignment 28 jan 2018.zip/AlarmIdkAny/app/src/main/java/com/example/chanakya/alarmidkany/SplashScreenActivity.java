package com.example.chanakya.alarmidkany;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SplashScreenActivity extends AppCompatActivity {

    /**
     * This class is usd to print the Splash screen
     * @param savedInstanceState
     *
     * This class will create the first activity to be displayed.
     * After displaying it for sometime the control is migrated to the other
     * activity whch asks username of the user.
     * This is done by using Intent.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashScreenActivity.this,UsernameActivity.class));

            }
        },5000);
    }
}
