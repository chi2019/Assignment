package com.example.chanakya.alarmidkany;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    /**
     * This class is uded to show the result of
     * the quiz performed by the user.
     * It lists out each and every question attempted by the user and also shows the
     * answer provided by him.
     */


    boolean[] userEvaluation = new boolean[10];
TextView result;
EditText name;
StringBuffer resultTemp = new StringBuffer("");
String[] questions = new String[10];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        result = findViewById(R.id.textViewResult); // This is used for the textview for ouputing the
                                                    // the result on the TextView
        name = findViewById(R.id.displayNameEditText);
                                           // This is used to output the name of the user attepted quiz


        userEvaluation = getIntent().getExtras().getBooleanArray("UserAnswers");
          // here we are trying to get the answers attempted by the user


           String userName = (String) getIntent().getExtras().get("username").toString();

           questions[0] = getString(R.string.qst_txt1);
           questions[1] = getString(R.string.qst_txt2);
           questions[2] = getString(R.string.qst_txt3);
           questions[3] = getString(R.string.qst_txt4);
           questions[4] = getString(R.string.qst_txt5);
           questions[5] = getString(R.string.qst_txt6);
           questions[6] = getString(R.string.qst_txt7);
           questions[7] = getString(R.string.qst_txt8);
           questions[8] = getString(R.string.qst_txt9);
           questions[9] = getString(R.string.qst_txt10);



           name.setText(userName + "   Ansers are as follows:" );

          for(int i=0;i<10;i++){



                      if(userEvaluation[i] == true) {
                          resultTemp.append(questions[i]);
                          resultTemp.append("\n");
                          resultTemp.append("Attemp:");
                          resultTemp.append("correct");
                          resultTemp.append("\n");
                          resultTemp.append("\n");
                          result.setText(resultTemp);
                      }

                      else {
                          resultTemp.append(questions[i]);
                          resultTemp.append("\n");
                          resultTemp.append("Attemp:");
                          resultTemp.append("wrong");
                          resultTemp.append("\n");
                          result.setText(resultTemp);
                      }
          }

    }
}
