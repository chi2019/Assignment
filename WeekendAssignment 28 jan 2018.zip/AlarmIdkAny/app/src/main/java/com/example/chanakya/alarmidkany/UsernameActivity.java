package com.example.chanakya.alarmidkany;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UsernameActivity extends AppCompatActivity {
    /**
     * This cass is just used to ask the username of the user
     *
     */
    TextView userName;   // This textview is used to ask the name of the user
    Button buttonforNext; // this button will migrate the user to the quiz using onClickListner

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_username);

        userName = (TextView)findViewById(R.id.userNameTextView);
        buttonforNext = findViewById(R.id.buttonforQuestions);


        /**
         * This onclickListner is set for the next button which will migrate the user
         * to the quiz by using intent.
         */
        buttonforNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(UsernameActivity.this,MainActivity.class);

                intent.putExtra("username",userName.getText().toString());

                startActivity(intent);




            }
        });



    }
}
