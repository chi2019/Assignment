package com.example.chanakya.alarmidkany;

/**
 * Created by chanakya on 1/27/2018.
 */

public class QuestionBank {
    /**
     * This class is used to store data in the form of objects
     * and acts as Model of Model View Controller model.
     */
    private int question;
    private boolean isQuestiontrue;

    public QuestionBank(int question,boolean isQuestiontrue ){
       this.isQuestiontrue = isQuestiontrue;
       this.question = question;
    }

    public int getQuestion() {
        return question;
    }

    public void setQuestion(int question) {
        this.question = question;
    }

    public boolean isQuestiontrue() {
        return isQuestiontrue;
    }

    public void setQuestiontrue(boolean questiontrue) {
        isQuestiontrue = questiontrue;
    }
}
