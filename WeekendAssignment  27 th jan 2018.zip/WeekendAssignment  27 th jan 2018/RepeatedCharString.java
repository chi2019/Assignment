//PseudoCode
/*
 * Step1: Convert the given string into char[].
 * Step2: For each and every character in array calculate the first and last
 * occurrence of the character in the string.
 * Step3: If the first occurrence and last occurrence of the string is
 * not same and the element is visited for the first time, then store that element
 * and increment the countChar variables to be printed.        
 */

public class RepeatedCharString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "geekforgeeks";
		
		int countChar =0;
		
		char ch[] = str.toCharArray();
		
		StringBuilder sb = new StringBuilder("");
		
		for(int  i=0;i<ch.length;i++) {
			
			if( str.indexOf(ch[i]) != (str.lastIndexOf(ch[i]))  ) {
				
				if(!sb.toString().contains(String.valueOf(ch[i]))) {
				
					sb.append(ch[i]);
					countChar++;
				}
				
			}
			
		}
		
		System.out.println("repeated elements:" + sb.toString() );
		System.out.println("no: of repeated elements" + countChar);
		
		
	}

}


//Trace
/*
 *          i                 str.indexOf(ch[i])     (str.lastIndexOf(ch[i]))
 *          
 *          0                       0                    0           
 *          1                       1                    2    
 *          2                       1                    2
 *          3                       3                    3
 *             
 */


//TestCases
/*
 *  input:  geek
 *  output:
 *          repeated elements:e
 *			no: of repeated elements1
 *
 *  input:  geekforgeeks
 *  output: 
 *  		repeated elements:gek
 *  		no: of repeated elements3
 *
 */






