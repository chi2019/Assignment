//PseudoCode
/*
 * Step1: Add two numbers and store it in first variable.
 * Step2: Subtract first from the second and store it in first variable.
 * Step3: Subtract first from the second and store it in Second variable.  
 */

public class SwapTwoNumbersWithoutUsingThirdVar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
             int x=2;
             int y=3;
             
             System.out.println("x,y : "+ x + "," + y);
             
             x= x+y;
             y= x-y;
             x= x-y;
             
             System.out.println("x,y : "+ x + "," + y);
             
	}

}

//Trace
/*
 *                            x    y 
 *                            2    3
 *  
 * After addition             5    3
 * 
 * After 1st subtraction      5    2
 * 
 * After 2nd subtraction      3    2
 *      
 */


//TestCases
/*
 *    input:   2  3
 *    output:  3  2
 *
 *    input:   4  5
 *    output:  5  4  
 *    
 *    input:   7  6
 *    output:  6  7      
 */


