//PseudoCode
/*
 * Step1: Create a StringBuilder using given String.
 * Step2: Reverse the StringBuilder using reverse method.
 *     
 */

public class ReverString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	            String str = "chanakya";
	            
	            StringBuilder sb = new StringBuilder(str);
	            
	            System.out.println(sb.reverse());
	
	
	}
	

}


//TestCases
/*
 *   input:  hello 
 *   output: olleh
 *   
 *   input:  kkr 
 *   output: rkk
 *   
 *   input:  chanakya 
 *   output: aykanahc
 */

