//PseudoCode
/*
 *Step1:Initialize two variables n, value for no:values to be printed and 
 *the out put to be displayed on the console.
 *Step2:Print The value and increment the value.
 *Step3:Repeat Step 2 for iterations less than present row number.
 *Step4: Repeat step 3 for iterations equal to number of rows.     
 */


public class FloydsTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
               
		int numberOfRows=5;
		int value=1;
		
		for(int i=0;i<numberOfRows;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(value++);
			}
			System.out.println();
		}
		
	}

}



//Trace
/*
 *     i    j     output
 *     0    0       1
 *     1    0       2  
 *          1       2 3
 *     2    0       4
 *          1       4 5 
 *          2       4 5 6
 *     3    0       7
 *          1       7 8
 *          2       7 8 9
 *          3       7 8 9 10
 *          
 *     
 *     
 */

//TestCases
/*
 *  input:3
 *  output:
 *         1
 *		   23
 *		   456
 *  
 *  input:4
 *  output:
 *			  1
 *			  23
 *			  456
 *			  78910
 *  
 *  
 *  input:5
 *  output:
 *			  1
 *			  23
 *			  456
 *			  78910
 *			  1112131415
 *  
 */




