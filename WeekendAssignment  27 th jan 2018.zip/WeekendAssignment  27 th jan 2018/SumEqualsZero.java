//PseudoCode
/*
 *  Step1: Sort the given array elements using sort method.
 *  Step2: Select an element for comparision.
 *  Step3: Select other element except already 
 *  chosen element for comparison.
 *  Step4: Select other element except the above  
 *  two element for comparison.
 *  Step5: Repeat step2 for i=0......array.length-3 . 
 *  Step6: Repeat step3 for j=i+1......array.length-2 .
 *  Step7: Repeat step2 for k=j+1......array.length-1 .     
 */

public class SumEqualsZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            int[] S = {-1,0,1,2,-1,-4};
            
            sort(S);
            
            printTriplets(S);
            
	}

	
	private static void printTriplets(int[] s) {
		// TODO Auto-generated method stub
		
		int n= s.length;
		
		String str ="";
		
		for(int i=0;i<n-2;i++) {
			
			for(int j=i+1;j<n-1;j++) {
				
				for(int k=j+1;k<n;k++) {
					
					if(s[k]+s[j]+s[i] == 0) {
						
						String temp = String.valueOf(s[i]+ " "+ s[j] + " "+ s[k]);
                        
						if(!str.contains(temp)) {						
						str = str + String.valueOf(s[i] + " ");
						str = str + String.valueOf(s[j] + " ");
						str = str + String.valueOf(s[k] + " ");
						str = str + "\n";
                        }
						
					}
					
				}
				
			}
			
		}
		
		System.out.println(str);
	}


	private static void sort(int[] a) {
		// TODO Auto-generated method stub
	    int n = a.length;
		
			for(int i=0;i<=n;i++){
				for(int j=1;j<n-i;j++){
	                 

					if(a[j-1] > a[j]){
	                    int temp = a[j-1];
	                    a[j-1] = a[j];
	                    a[j] = temp;
	                 }
	                 
				}
			}
	}
}


//Trace
/*
 *      i    j     k      a[i]     a[j]    a[k]    //-4,-1,-1,0,1,2
 *      
 *      0    1     2      -4        -1      -1
 *                 3                         0      
 *                 4                         1
 *                 5                         2
 *      	 2     3                -1       0  
 *                 4                         1
 *                 5                         2
 *           3     4                 0       1
 *                 5                         2
 *           4     5                 1       2
 *      1    2     3      -1        -1       0    
 *                 4                         1
 *                 5                         2    -1 -1  2
 *           3     4                 0       1    -1  0  1 
 *                 5                         2
 *           4     5                 1       2
 *      2    3     4      -1         0       1
 *                 5                         2
 *           4     5                 1       2    
 *      3    4     5       0         1       2
 *      
 *      
 */


//TestCases
/*
 *   input: -1,0,1,2,-1,-4
 *   output:  -1 -1 2 
 *   		  -1 0 1 
 *
 *   input: 1,2,-1,-4
 *   output: -4 2 2  
 */

